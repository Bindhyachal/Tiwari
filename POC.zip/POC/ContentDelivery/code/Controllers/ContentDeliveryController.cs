﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sitecore;
using Sitecore.Security;
using Newtonsoft.Json;
using YasConnect.Foundation.ContentDelivery.Models;
using Newtonsoft.Json.Linq;
using Sitecore.Data;
using Sitecore.Data.Items;
using Sitecore.SecurityModel;
using YasConnect.Foundation.ContentDelivery;

namespace YasConnect.Foundation.ContentDelivery.Controllers
{
    public class ContentDeliveryController : Controller
    {
        Database masterDb = Sitecore.Configuration.Factory.GetDatabase("master");
        // GET: ContentDelivery
        [HttpGet]
        public ActionResult ContentDelivery(string Id)
        {
            var status = CreateItem(Id);
            return View("~/Views/ContentDelivery/ContentDelivery.cshtml", status);
        }

        public bool CreateItem(string Id)
        {
            var Parent = masterDb.GetItem(new ID(Id));
            var Value = Parent != null ? Parent.Fields["Description"].Value : string.Empty;
            var Object = isValidJSON(Value) ? JsonConvert.DeserializeObject<ParentObject>(Value) : null;
            //return 
            var templateItem = GenerateTemplate(Object.MainJson, Miralconstant.TempaltePathId);
            return GenrateSitecoreItem(Object.MainJson, Parent, templateItem); ;
        }

        public bool isValidJSON(string json)
        {
            try
            {
                JToken token = JObject.Parse(json);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        //public bool GenrateSitecoreItem(MainJson parent, Item Parent)
        //{
        //    if (parent != null && parent.ContentModel.Count > 0)
        //    {
        //        foreach (var _child in parent.ContentModel)
        //        {
        //            using (new SecurityDisabler())
        //            {
        //                if (_child.Question.Equals("SingleLineText"))
        //                {
        //                    TemplateItem template = masterDb.GetTemplate(new ID(Miralconstant.SingleLineText));
        //                    Parent.Add("Question", template);
        //                }
        //                if (_child.Question.Equals("RichText"))
        //                {
        //                    TemplateItem template = masterDb.GetTemplate(new ID(Miralconstant.RichText));
        //                    Parent.Add("Question", template);
        //                }
        //                if (_child.Answer.Equals("SingleLineText"))
        //                {
        //                    TemplateItem template = masterDb.GetTemplate(new ID(Miralconstant.SingleLineText));

        //                    Parent.Add("Answer", template);
        //                }
        //                if (_child.Answer.Equals("RichText"))
        //                {
        //                    TemplateItem template = masterDb.GetTemplate(new ID(Miralconstant.RichText));

        //                    Parent.Add("Answer", template);
        //                }

        //            }
        //        }
        //        return true;
        //    }
        //    return false;
        //}
        public bool GenrateSitecoreItem(MainJson parent, Item Parent, string templateID)
        {
            if (parent != null && parent.ContentModel.Count > 0)
            {
                foreach (var _child in parent.ContentModel)
                {
                    using (new SecurityDisabler())
                    {
                        TemplateItem template = masterDb.GetTemplate(new ID(templateID));
                        var DynamicItem = Parent.Add("NewItem", template);
                        DynamicItem.Editing.BeginEdit();
                        DynamicItem.Fields[template.OwnFields[0].Name].Value = _child.Answer;
                        DynamicItem.Fields[template.OwnFields[1].Name].Value = _child.Question;
                        DynamicItem.Editing.EndEdit();
                    }
                }
                return true;
            }
            return false;
        }

        private string GenerateTemplate(MainJson tmpObjModel, string tempatePathID)
        {
            string ItemID = string.Empty;
            //const string templateOftemplateFieldId = "{455A3E98-A627-4B40-8035-E683A0331AC7}";
            if (tmpObjModel != null)
            {
                //foreach (var _child in tmpObjModel.TemplateModel)
                //{
                using (new SecurityDisabler())
                {
                    var ParentFolder = masterDb.GetItem(new ID(tempatePathID));
                    TemplateItem template = masterDb.GetTemplate(new ID(Miralconstant.StandardTempId));
                    Item NewItem = ParentFolder.Add("DynamicTemplate", template);
                    ItemID = NewItem.ID.ToString();
                    TemplateItem newTemplate = new TemplateItem(NewItem);
                    TemplateSectionItem templateSection = newTemplate.AddSection(tmpObjModel.Section);

                    if (NewItem != null)
                    {
                        if (templateSection != null)
                        {
                            var newField = templateSection.AddField("Title");
                            newField.BeginEdit();
                            newField.Type = tmpObjModel.TemplateModel.Title;
                            newField.EndEdit();


                            var newField1 = templateSection.AddField("Description");
                            newField1.BeginEdit();
                            newField1.Type = tmpObjModel.TemplateModel.Decription;
                            newField1.EndEdit();
                        }
                    }
                }
                //}
                return ItemID;
            }
            return string.Empty;
        }
    }
}