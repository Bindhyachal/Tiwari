﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace YasConnect.Foundation.ContentDelivery.Models
{
    //public class ContentModel
    //{
    //    public string Question { get; set; }
    //    public string Answer { get; set; }
    //}

    //public class TemplateModel
    //{
    //    public string Section { get; set; }
    //    public string Tile { get; set; }
    //    public string Decription { get; set; }
    //    public string Image { get; set; }
    //}

    //public class MainJson
    //{
    //    public List<ContentModel> ContentModel { get; set; }
    //    public List<TemplateModel> TemplateModel { get; set; }
    //}

    //public class ParentObject
    //{
    //    public MainJson MainJson { get; set; }
    //}


    public class ContentModel
    {
        public string Question { get; set; }
        public string Answer { get; set; }
    }

    public class TemplateModel
    {
        public string Title { get; set; }
        public string Decription { get; set; }
    }

    public class MainJson
    {
        public List<ContentModel> ContentModel { get; set; }
        public string Section { get; set; }
        public TemplateModel TemplateModel { get; set; }
    }

    public class ParentObject
    {
        public MainJson MainJson { get; set; }
    }
}