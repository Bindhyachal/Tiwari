﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace YasConnect.Foundation.ContentDelivery
{
    public class Miralconstant
    {
        public const string SingleLineText = "{72A28596-1CE0-49A9-BDC1-292AF7D55503}";
        public const string RichText = "{226B47E4-9E8F-4055-B3F5-18A4DD4FC9AD}";
        public const string TempaltePathId = "{47D43CC0-8948-45B4-B8B6-DEE8304DDF11}";
        public const string StandardTempId = "{AB86861A-6030-46C5-B394-E8F99E8B87DB}";
    }
}