﻿using YasConnect.Feature.Platform.FAQ.Models;
using YasConnect.Foundation.Base.Controllers;
using YasConnect.Foundation.Core.Repositiories;

using Sitecore;
using Sitecore.Mvc.Presentation;
using Sitecore.Web.UI.WebControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace YasConnect.Feature.Platform.FAQ.Controllers
{
    public class FAQController : BaseController
    {
        Logger Logger = new Logger();
        FAQModel FAQobj = new FAQModel();

        // GET: FAQ
        public ActionResult FAQAccordian()
        {
            Logger.LogInfo("FAQ: Enter in FAQAccordian Action Method");

            var DataSource = RenderingContext.Current.Rendering.DataSource;
            Logger.LogInfo("FAQ: Datasource is now set, datasource used is: " + DataSource);

            var item = Context.Database.GetItem(DataSource);
            
            FAQobj.Question = item.Fields["Question"]?.Value ?? string.Empty;
            FAQobj.Answer = item.Fields["Answer"]?.Value ?? string.Empty;

            //Logger.LogInfo("Test Error Start");
            //Int32 i = 7;
            //Int32 j = 0;
            //int x = i / j;
            //Logger.LogInfo("Test Error end");

            return View("~/Views/Platform/FAQ/FAQAccordian.cshtml", FAQobj);
        }

    }
}