﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace YasConnect.Feature.Platform.FAQ.Models
{
    public interface IMapper
    {
        FAQModel GetFAQComponent(string id);
    }
}