﻿using YasConnect.Feature.Platform.FAQ.Models;
using Sitecore.Data;
using Sitecore.Data.Items;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace YasConnect.Feature.Platform.FAQ.Repositories
{
    public class ItemMapper : IMapper
    {
        FAQModel faqModel = new FAQModel();
        public FAQModel GetFAQComponent(string id)
        {
            Database sitecoreDb = Sitecore.Configuration.Factory.GetDatabase("master");

            Item entryFolderItem = sitecoreDb.Items[id];

            faqModel.Question = entryFolderItem.Fields["Question"].ToString();
            faqModel.Answer = entryFolderItem.Fields["Answer"].ToString();

            return faqModel;
        }
    }
}