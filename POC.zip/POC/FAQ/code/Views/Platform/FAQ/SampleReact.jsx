﻿var SampleReact = React.createClass({
    render: function() {
        return (
                        <div>
                <h1 dangerouslySetInnerHTML={{ __html: this.props.data.Question }}></h1>
                <div dangerouslySetInnerHTML={{__html: this.props.data.Answer}}></div>
</div>
        );
}
});