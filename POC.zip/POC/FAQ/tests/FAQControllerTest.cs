﻿namespace YasConnect.Feature.Platform.FAQ.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Web.Mvc;
    using FluentAssertions;
    using Sitecore.Data;
    using Sitecore.FakeDb;
    using YasConnect.Feature.Platform.FAQ.Controllers;

    using Sitecore.Mvc.Common;
    using Sitecore.Mvc.Presentation;

    using Xunit;
    using YasConnect.Feature.Platform.FAQ.Tests.Extensions;

    public class FAQControllerTest
    {
        [Theory]
        [AutoDbData]
        public void FAQ_ShouldReturnViewResult(Db db, string itemName, ID itemId)
        {
            //Arrange
            var DataItem = "miral";
            db.Add(new DbItem("miral") { { "Question", "How are you"},{ "Answer", "I am fine thanks" } });
            var DataSource = "/sitecore/content/" + DataItem;

            var item = db.GetItem(DataSource);
            var context = new RenderingContext();
            context.Rendering = new Rendering();
            context.Rendering.Item = item;
            context.Rendering.DataSource = DataSource;
            ContextService.Get().Push(context);           
            var controller = new FAQController();           
            //Act
            var list = controller.FAQAccordian();
            //Assert      
            list.Should().BeOfType<ViewResult>();
        }

        [Fact]
        [AutoDbData]
        public void FAQ_FACT()
        {
            Db db = new Db() { new DbItem("miral") { { "Question", "How are you" }, { "Answer", "I am fine thanks" } } };
            var context = new RenderingContext();
            context.Rendering = new Rendering();
            context.Rendering.DataSource = "/sitecore/content/miral";
            ContextService.Get().Push(context);
            var obj = new FAQController();
            var actResult = obj.FAQAccordian() as ViewResult;
            Assert.Equal("~/Views/FAQ/FAQAccordian.cshtml", actResult.ViewName);

        }
    }
}
