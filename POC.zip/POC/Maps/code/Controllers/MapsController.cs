﻿using YasConnect.Foundation.Base.Controllers;
using Sitecore.Mvc.Presentation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Sitecore.Web.UI.WebControls;
using YasConnect.Feature.Platform.Maps.Models;

using YasConnect.Feature.Platform.Maps.Repositories;
using System.Web.Script.Serialization;
using YasConnect.Foundation.Core.Repositiories;

namespace YasConnect.Feature.Platform.Maps.Controllers
{
    public class MapsController : BaseController
    {
        Logger Logger = new Logger();
        private IMapper itemMapper;
        public MapsController(IMapper _mapper)
        {
            itemMapper = _mapper;
        }
    

        public ActionResult Maps()
        {
            Logger.LogInfo("Loading Maps React Component");
            string dataSource = RenderingContext.Current.Rendering.DataSource;
            if (string.IsNullOrEmpty(dataSource)) return null;
            Logger.LogInfo("Map Controller:Maps-Going to fetch MapModel from sitecore database");
            var item = itemMapper.GetMapModel(dataSource);

            Logger.LogInfo("Converting Maps Model into JSON");
            var json = Newtonsoft.Json.JsonConvert.SerializeObject(item, Newtonsoft.Json.Formatting.None);
            ViewBag.jsonData = json;
            ViewBag.GUID = item.Guid;
            return View("~/Views/Platform/Maps/Maps.cshtml", item);
            //return this.React("MapsReact", item);
        }


        public ActionResult MapsView()
        {
            Logger.LogInfo("Loading Maps CsHtml Component");
            string dataSource = RenderingContext.Current.Rendering.DataSource;
            if (string.IsNullOrEmpty(dataSource)) return null;            
        

            Logger.LogInfo("Item Mapper starting Mapping of Fields in Model");
            var item = itemMapper.GetMapModel(dataSource);

            Logger.LogInfo("Converting Maps Model into JSON");
            var json = Newtonsoft.Json.JsonConvert.SerializeObject(item, Newtonsoft.Json.Formatting.None);
            ViewBag.jsonData = json;
            return View("~/Views/Platform/Maps/MapsView.cshtml", item);
        }

     

            }
}