﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace YasConnect.Feature.Platform.Maps.Models
{
    public interface IMapper
    {
        MapModel MapObject(Sitecore.Data.Items.Item renderingItem);
        List<LocationModel> LocationMapper(string[] items);
        MapJsonModel MapJson(Sitecore.Data.Items.Item renderingItem);
        MapLabels MapLabel(Sitecore.Data.Items.Item renderingItem);
        MapJsonModel GetMapModel(string dataSource);
    }
}