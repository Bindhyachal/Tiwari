﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace YasConnect.Feature.Platform.Maps.Models
{

    public class GoogleMapModel
    {
        [JsonProperty(PropertyName = "locations")]
        public List<LocationModel> Locations { get; set; }

        [JsonProperty(PropertyName = "centerLatitude")]
        public double CenterLatitude { get; set; }

        [JsonProperty(PropertyName = "centerLongitude")]
        public double CenterLongitude { get; set; }
        [JsonProperty(PropertyName = "radius")]
        public int Radius { get; set; }
        [JsonProperty(PropertyName = "zoom")]
        public int Zoom { get; set; }

    }
    public class MapModel
    {
        [JsonProperty(PropertyName = "googleMap")]
        public GoogleMapModel GoogleMap { get; set; }
        [JsonProperty(PropertyName = "labels")]
        public MapLabels Labels { get; set; }
    }

    public class MapJsonModel
    { 
        [JsonProperty(PropertyName = "guid")]
        public string Guid { get; set; }
        [JsonProperty(PropertyName = "data")]
        public MapModel Data { get; set; }

        public string GoogleApiKey { get; set; }
    }

    public class MapLabels
    {
        [JsonProperty(PropertyName = "buttonText")]

        public string ButtonText { get; set; }

        [JsonProperty(PropertyName = "dropDownLabel")]

        public string DropdownLabel { get; set; }
    }

    public class LocationModel
    {
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }
        [JsonProperty(PropertyName = "latitude")]
        public double Latitude { get; set; }
        [JsonProperty(PropertyName = "longitude")]
        public double Longitude { get; set; }
        [JsonProperty(PropertyName = "isDefault")]
        public bool IsDefault { get; set; }

    }

}