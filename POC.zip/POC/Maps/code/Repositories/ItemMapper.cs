﻿using YasConnect.Feature.Platform.Maps.Models;
using YasConnect.Foundation.Core.Repositiories;
using Sitecore.Web.UI.WebControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using YasConnect.Foundation.DependencyInjection;
using YasConnect.Foundation.SitecoreExtensions.Extensions;

namespace YasConnect.Feature.Platform.Maps.Repositories
{
    [Service(typeof(IMapper))]
    public class ItemMapper : IMapper
    {
        Logger logger = new Logger();
        public List<LocationModel> LocationMapper(string[] items)
        {
            logger.LogInfo("Mapping Locations into Map Model");
            List<LocationModel> Locations = new List<LocationModel>();
            foreach (var item in items)
            {
                var location = Sitecore.Context.Database.GetItem(new Sitecore.Data.ID(item));
                Locations.Add(new LocationModel()
                {
                    Latitude = location.Fields[Templates.Location.Fields.Latitude]!=null ? CheckDoubleValue(location.Fields[Templates.Location.Fields.Latitude].Value) :0.0,
                    Longitude = location.Fields[Templates.Location.Fields.Longitude] !=null ? CheckDoubleValue(location.Fields[Templates.Location.Fields.Longitude].Value):0.0,
                    Name = location.Fields[Templates.Location.Fields.Name]!=null?location.Fields[Templates.Location.Fields.Name].Value:"",
                    IsDefault = location.Fields[Templates.Location.Fields.IsDefault] !=null? location.Fields[Templates.Location.Fields.IsDefault].Value.Equals("1") ? true : false:false
                });
            }
            return Locations;
        }
        double CheckDoubleValue(string value)
        {
            try
            {
                return Convert.ToDouble(value);
            }
            catch (Exception ex)
            {
                logger.LogException(ex);
            }
            return 0.0;
        }
        public MapModel MapObject(Sitecore.Data.Items.Item renderingItem)
        {
            logger.LogInfo("Mapping Map Central Location into Map Model");
            return new MapModel
            {                
                GoogleMap = new Models.GoogleMapModel
                {
                    CenterLatitude = renderingItem.Fields[Templates.Map.Fields.CenterLatitude] !=null ? CheckDoubleValue(renderingItem.Fields[Templates.Map.Fields.CenterLatitude].Value):0.0,
                    CenterLongitude = renderingItem.Fields[Templates.Map.Fields.CenterLongitude] !=null ? CheckDoubleValue(renderingItem.Fields[Templates.Map.Fields.CenterLongitude].Value):0.0,
                    Radius = renderingItem.Fields[Templates.Map.Fields.Radius] !=null ? Convert.ToInt32(renderingItem.Fields[Templates.Map.Fields.Radius].Value):0,
                    Zoom = renderingItem.Fields[Templates.Map.Fields.Zoom]!=null ? Convert.ToInt32(renderingItem.Fields[Templates.Map.Fields.Zoom].Value):0,
                    Locations = renderingItem.Fields[Templates.Map.Fields.Locations] != null?LocationMapper(renderingItem.Fields[Templates.Map.Fields.Locations].Value.Split('|')):new List<LocationModel>()
                },
               
                Labels = MapLabel(renderingItem)
            };
        }
        public MapLabels MapLabel(Sitecore.Data.Items.Item renderingItem)
        {
            logger.LogInfo("Mapping Labels into Map Model");
            return new MapLabels
            {
               ButtonText = FieldRenderer.Render(renderingItem, Templates.Map.Fields.ButtonText.ToString()),
               DropdownLabel = FieldRenderer.Render(renderingItem, Templates.Map.Fields.ButtonText.ToString())
            };
        }
        public MapJsonModel MapJson(Sitecore.Data.Items.Item renderingItem)
        {
            logger.LogInfo("Mapping All info into Map Model");
            MapJsonModel model = new MapJsonModel();
            try
            {
                model = new MapJsonModel
                {
                    Data = MapObject(renderingItem),
                    Guid = Guid.NewGuid().ToString(),
                    GoogleApiKey = renderingItem.Fields[Templates.Map.Fields.ApiKey] != null ? renderingItem.Fields[Templates.Map.Fields.ApiKey].Value : ""
                };
            }
            catch (Exception ex)
            {
                logger.LogError("Controller Maps Item mapping", ex);

            }
            return model;
        }
        /// <summary>
        /// Fetch MapJson Model from Sitecore database using data source
        /// </summary>
        /// <param name="dataSource"></param>
        /// <returns></returns>
        public MapJsonModel GetMapModel(string dataSource)
        {
            logger.LogInfo("Get MapModel:Fetching Map model from sitecore database");
            var renderingItem = ItemExtensions.GetItem(dataSource);
            var mapJsonModel = new MapJsonModel();
            if (renderingItem != null)
            {
                mapJsonModel = MapJson(renderingItem);
            }
            logger.LogInfo("GetMapModel:Returning MapModel");
            return mapJsonModel;
        }
    }
}