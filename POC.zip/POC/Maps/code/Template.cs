﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace YasConnect.Feature.Platform.Maps
{
    using Sitecore.Data;
    public struct Templates
    {
        public struct Map
        {
            public static readonly ID ID = new ID("{DEA786D6-158F-4B8F-ADFA-B235AE75AA4B}");
            public struct Fields
            {
                public static readonly ID Locations = new ID("{B7B0784B-5073-43C3-9920-6397BBA3BF98}");
                public static readonly ID CenterLatitude = new ID("{B2AAE110-314B-4FCE-AA96-7AD3F56CEF1D}");
                public static readonly ID CenterLongitude = new ID("{6B6B463B-F21A-489A-B81B-124A5ADE291A}");
                public static readonly ID Radius = new ID("{56D3541D-4E5F-4D41-9818-8426E5C0C230}");
                public static readonly ID Zoom = new ID("{2087DEB0-5E6D-4D51-BED3-ECB771291894}");
                public static readonly ID ApiKey = new ID("{2D347A6C-FCB2-42AC-9569-FFA374E992D8}");
                public static readonly ID ButtonText = new ID("{2C192F50-EA56-44A5-8401-9929BF689C8C}");
                public static readonly ID DropdownLabel = new ID("{CC475A78-D8BA-4550-B420-8540AFA265D1}");
            }
        }
        public struct Location
        {
            public static readonly ID ID = new ID("{A3E7F75E-AC30-41BC-B15C-96410E5B5435}");
            public struct Fields
            {
                public static readonly ID Name = new ID("{1C97B634-1C30-481D-86A1-4E746BDBC6D6}");
                public static readonly ID Latitude = new ID("{BD183779-2EC7-4B52-B078-47435F2C6874}");
                public static readonly ID Longitude = new ID("{6C75D52B-7F5B-48AE-ADFC-466FD77CC334}");
                public static readonly ID IsDefault = new ID("{5534C449-1296-49CB-9EE2-0BB984552361}");
            }
        }
    }
}