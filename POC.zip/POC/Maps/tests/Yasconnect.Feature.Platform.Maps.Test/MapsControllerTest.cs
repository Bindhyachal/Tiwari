﻿using FluentAssertions;
using YasConnect.Feature.Platform.Maps.Controllers;
using YasConnect.Feature.Platform.Maps.Models;
using YasConnect.Foundation.Testing.Extensions;
using Moq;
using NSubstitute;
using Sitecore.Data;
using Sitecore.FakeDb;
using Sitecore.Mvc.Common;
using Sitecore.Mvc.Presentation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using Xunit;

namespace YasConnect.Feature.Platform.Maps.Test
{

    public class MapsControllerTest
    {
        [Theory]
        [AutoDbData]
        public void MAP_ShouldReturnViewResult(Db db, string itemName, ID itemId)
        {
            //Arrange
            var DataItem = "map";
            Sitecore.Data.Database database = Sitecore.Configuration.Factory.GetDatabase("master");

            CreateDbItem(db);

            var DataSource = "/sitecore/content/" + DataItem;

            var item = db.GetItem(DataSource);
            var context = new RenderingContext();
            context.Rendering = new Rendering();
            context.Rendering.Item = item;
            context.Rendering.DataSource = DataSource;
            ContextService.Get().Push(context);
            Mock<IMapper> newObj = new Mock<IMapper>();
            newObj.Setup(m => m.GetMapModel(DataSource)).Returns(ItemMapperforTest(item));
            var controller = new MapsController(newObj.Object);
            //Act
            var list = controller.Maps();
            //Assert
            list.Should().BeOfType<ViewResult>();
        }

        private static void CreateDbItem(Db db)
        {
            DbItem loc1 = new DbItem("Loaction")
            {
                { "Latitude", "54" },
                { "Longitude", "55" },
                { "Name", "YWW" },
                { "IsDefault", "true" }
            };
            DbItem loc12 = new DbItem("Loaction")
            {
                { "Latitude", "54" },
                        { "Longitude", "55" },
                        { "Name", "FWW" },
                        { "IsDefault", "true" }
            };         

            DbItem map = new DbItem("map") {
                { "Locations",loc1.ID.ToString()+"|"+loc12.ID.ToString()},
               { "CenterLatitude", "11" },
                { "CenterLongitude", "11" },
                { "Radius", "110" },
                { "Zoom", "10" }
            };
            map.Add(loc1);
            map.Add(loc12);

            db.Add(map);
        }

        private MapJsonModel ItemMapperforTest(Sitecore.Data.Items.Item renderingItem)
        {
            return new MapJsonModel
            {                
                Guid = Guid.NewGuid().ToString(),
                Data = new MapModel
                {
                    GoogleMap = new GoogleMapModel
                    {
                        CenterLatitude = Convert.ToDouble(renderingItem.Fields["CenterLatitude"].Value),
                        CenterLongitude = Convert.ToDouble(renderingItem.Fields["CenterLongitude"].Value),
                        Radius = Convert.ToInt32(renderingItem.Fields["Radius"].Value),
                        Zoom = Convert.ToInt32(renderingItem.Fields["Zoom"].Value),
                        Locations = LocationMapperForTest(renderingItem.Fields["Locations"].Value.Split('|'))
                    },
                    Labels = new MapLabels(),
                }
            };
        }
        private List<LocationModel> LocationMapperForTest(string[] items)
        {
            List<LocationModel> Locations = new List<LocationModel>();
            foreach (var item in items)
            {
                var location = Sitecore.Context.Database.GetItem(new Sitecore.Data.ID(item));
                Locations.Add(new LocationModel()
                {
                    Latitude = Convert.ToDouble(location.Fields["Latitude"].Value),
                    Longitude = Convert.ToDouble(location.Fields["Longitude"].Value),
                    Name = location.Fields["Name"].Value,
                    IsDefault = location.Fields["IsDefault"].Value != "1" ? true : false
                });
            }
            return Locations;
        }
    }
}
